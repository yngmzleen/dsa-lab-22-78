#!/bin/bash

# Получаем имя файла из первого аргумента
filename="/Users/egorivanov/Documents/7 семестр/РПП/dsa-lab-22-78/7 sem/calculator.sh"

if [ ! -f "$filename" ]; then
    echo "Ошибка: Файл '$filename' не существует"
    exit 1
fi

echo "Статистика для файла '$filename':"

# Подсчитываем количество строк
lines=$(wc -l < "$filename")
echo "Количество строк: $lines"

# Подсчитываем количество слов
words=$(wc -w < "$filename")
echo "Количество слов: $words"

# Подсчитываем количество символов
chars=$(wc -c < "$filename")
echo "Количество символов: $chars"
